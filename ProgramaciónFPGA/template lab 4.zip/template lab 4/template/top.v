//==============================================================
//  CAJA FUERTE - Altera Cyclone IV  (reloj de 50 MHz)
//
//  3 estados principales:
//    1) IngresarClave  (estado inicial)
//    2) Desbloqueado
//    3) CambiarClave
//
//  La comunicacion con la LCD (PCF8574T @ 0x27) reutiliza el
//  MISMO motor I2C que ya te funciono en el banco de pruebas;
//  solo se hizo dinamico para poder cambiar mensajes y mostrar
//  los digitos tecleados.
//
//  Mapeo del PCF8574 (modulo comercial):
//    bit7..bit4 = D7..D4   bit3 = Backlight   bit2 = EN
//    bit1 = RW(0)          bit0 = RS
//==============================================================


//--------------------------------------------------------------
//  MODULO 1: Teclado matricial 4x4 con antirrebote
//  filas = salidas (activa en bajo), columnas = entradas con
//  pull-up (tecla presionada = 0). Entrega un pulso TeclaValida
//  por cada pulsacion nueva.
//
//  Codigos: 0-9 = numeros, 10..13 = A..D, 14 = '*', 15 = '#'
//--------------------------------------------------------------
module TecladoMatricial (
    input  wire       clk,
    input  wire       rst,
    output reg  [3:0] filas,
    input  wire [3:0] columnas,
    output reg  [3:0] codigoTecla,
    output reg        teclaValida
);
    reg [15:0] divEscaneo;
    reg [1:0]  filaActual;
    reg        teclaSostenida;

    // decodifica la fila activa + el patron de columnas
    function [3:0] decodificar;
        input [1:0] f;
        input [3:0] c;
        begin
            case (f)
              2'd0: case (c)              // fila 0: 1 2 3 A
                      4'b1110: decodificar = 4'd1;
                      4'b1101: decodificar = 4'd2;
                      4'b1011: decodificar = 4'd3;
                      4'b0111: decodificar = 4'd10;  // A
                      default: decodificar = 4'hF;
                    endcase
              2'd1: case (c)              // fila 1: 4 5 6 B
                      4'b1110: decodificar = 4'd4;
                      4'b1101: decodificar = 4'd5;
                      4'b1011: decodificar = 4'd6;
                      4'b0111: decodificar = 4'd11;  // B
                      default: decodificar = 4'hF;
                    endcase
              2'd2: case (c)              // fila 2: 7 8 9 C
                      4'b1110: decodificar = 4'd7;
                      4'b1101: decodificar = 4'd8;
                      4'b1011: decodificar = 4'd9;
                      4'b0111: decodificar = 4'd12;  // C
                      default: decodificar = 4'hF;
                    endcase
              2'd3: case (c)              // fila 3: * 0 # D
                      4'b1110: decodificar = 4'd14;  // *
                      4'b1101: decodificar = 4'd0;
                      4'b1011: decodificar = 4'd15;  // #
                      4'b0111: decodificar = 4'd13;  // D
                      default: decodificar = 4'hF;
                    endcase
              default: decodificar = 4'hF;
            endcase
        end
    endfunction

    wire [3:0] teclaLeida = decodificar(filaActual, columnas);

    always @(posedge clk or posedge rst) begin
        if (rst) begin
            divEscaneo<=16'd0; filaActual<=2'd0; filas<=4'b1110;
            teclaValida<=1'b0; teclaSostenida<=1'b0; codigoTecla<=4'hF;
        end else begin
            teclaValida <= 1'b0;                 // pulso por defecto en 0
            if (divEscaneo == 16'd50000) begin   // ~1 ms por paso (antirrebote)
                divEscaneo <= 16'd0;
                if (teclaLeida != 4'hF) begin
                    // hay una tecla en la fila actual
                    if (!teclaSostenida) begin
                        teclaSostenida <= 1'b1;
                        codigoTecla    <= teclaLeida;
                        teclaValida    <= 1'b1;  // un solo pulso por pulsacion
                    end
                end else begin
                    // sin tecla: liberar y avanzar a la siguiente fila
                    if (columnas == 4'b1111) teclaSostenida <= 1'b0;
                    filaActual <= filaActual + 2'd1;
                    case (filaActual + 2'd1)
                      2'd0: filas <= 4'b1110;
                      2'd1: filas <= 4'b1101;
                      2'd2: filas <= 4'b1011;
                      2'd3: filas <= 4'b0111;
                    endcase
                end
            end else divEscaneo <= divEscaneo + 16'd1;
        end
    end
endmodule


//--------------------------------------------------------------
//  MODULO 2: Motor I2C  (basado en tu codigo probado)
//  Envia UN byte hacia el PCF8574: START + direccion(0x4E) +
//  dato + STOP. Se dispara con un pulso 'arrancar' y avisa con
//  'listo'. SDA en colector abierto, SCL push-pull (igual que
//  tu version que ya funciono con el convertidor de nivel).
//--------------------------------------------------------------
module MotorI2C (
    input  wire       clk,
    input  wire       rst,
    input  wire       tick,        // pulso de 5 us (paso de la maquina I2C)
    input  wire       arrancar,    // pulso para iniciar el envio de 1 byte
    input  wire [7:0] dato,        // byte a enviar al PCF8574
    output reg        listo,       // 1 = libre / terminado
    inout  wire       sda,
    output wire       scl
);
    parameter [7:0] DIRI2C = 8'h4E;   // 0x27 << 1 (bit de escritura = 0)

    reg sdaOut, sdaDir, sclOut;
    assign sda = (sdaDir && sdaOut == 1'b0) ? 1'b0 : 1'bz;  // colector abierto
    assign scl = sclOut;

    localparam Reposo=0, IniA=1, IniB=2, BitBajo=3, BitAlto=4,
               AckBajo=5, AckAlto=6, StopA=7, StopB=8, StopC=9, Fin=10;

    reg [3:0] est;
    reg [2:0] cuenta;
    reg       esDir;        // 1 = enviando direccion, 0 = enviando dato
    reg [7:0] datoReg;

    // captura el pulso 'arrancar' en cualquier ciclo (no se pierde
    // aunque no coincida con un 'tick')
    reg pedido;
    always @(posedge clk or posedge rst) begin
        if (rst)            pedido <= 1'b0;
        else if (arrancar)  pedido <= 1'b1;
        else if (!listo)    pedido <= 1'b0;
    end

    always @(posedge clk or posedge rst) begin
        if (rst) begin
            est<=Reposo; listo<=1'b1; sdaOut<=1'b1; sdaDir<=1'b1; sclOut<=1'b1;
            cuenta<=3'd0; esDir<=1'b0; datoReg<=8'h00;
        end else if (tick) begin
            case (est)
              Reposo: begin
                  sclOut<=1'b1; sdaOut<=1'b1; sdaDir<=1'b1;
                  if (pedido) begin listo<=1'b0; datoReg<=dato; est<=IniA; end
                  else        listo<=1'b1;
              end
              // START: SDA baja con SCL alto
              IniA: begin sclOut<=1'b1; sdaDir<=1'b1; sdaOut<=1'b0; est<=IniB; end
              IniB: begin sclOut<=1'b0; esDir<=1'b1; cuenta<=3'd7; est<=BitBajo; end
              // envio de 8 bits (MSB primero)
              BitBajo: begin
                  sclOut<=1'b0; sdaDir<=1'b1;
                  sdaOut <= esDir ? DIRI2C[cuenta] : datoReg[cuenta];
                  est<=BitAlto;
              end
              BitAlto: begin
                  sclOut<=1'b1;
                  if (cuenta==3'd0) est<=AckBajo;
                  else begin cuenta<=cuenta-3'd1; est<=BitBajo; end
              end
              // noveno pulso = ACK del esclavo (se libera SDA, no se valida)
              AckBajo: begin sclOut<=1'b0; sdaDir<=1'b0; est<=AckAlto; end
              AckAlto: begin
                  sclOut<=1'b1;
                  if (esDir) begin esDir<=1'b0; cuenta<=3'd7; est<=BitBajo; end
                  else est<=StopA;
              end
              // STOP: SDA sube con SCL alto
              StopA: begin sclOut<=1'b0; sdaDir<=1'b1; sdaOut<=1'b0; est<=StopB; end
              StopB: begin sclOut<=1'b1; sdaOut<=1'b0; est<=StopC; end
              StopC: begin sclOut<=1'b1; sdaOut<=1'b1; est<=Fin; end
              Fin: begin listo<=1'b1; est<=Reposo; end
              default: est<=Reposo;
            endcase
        end
    end
endmodule


//--------------------------------------------------------------
//  MODULO 3: Controlador de LCD
//  - Genera el 'tick' de 5 us y contiene el MotorI2C.
//  - Inicializa la LCD (misma secuencia que tu prueba).
//  - Ofrece dos ordenes al modulo principal:
//      cmdRefrescar : limpia, escribe el mensaje (selMsg) en la
//                     fila 1, deja la fila 2 en blanco y pone el
//                     cursor al inicio de la fila 2.
//      cmdEscribir  : escribe un caracter en la posicion actual
//                     (para ir mostrando los digitos tecleados).
//  - 'libre' = 1 cuando la LCD esta lista para una nueva orden.
//--------------------------------------------------------------
module ControladorLCD (
    input  wire       clk,
    input  wire       rst,
    input  wire [1:0] selMsg,        // 0=Ingresar 1=Desbloqueado 2=Cambiar
    input  wire       cmdRefrescar,  // pulso
    input  wire       cmdEscribir,   // pulso
    input  wire [7:0] caracter,      // caracter a escribir
    output wire       libre,
    inout  wire       sda,
    output wire       scl
);
    // ---------- tick de 5 us (200 kHz) ----------
    reg [7:0] divTick; reg tick;
    always @(posedge clk or posedge rst) begin
        if (rst) begin divTick<=8'd0; tick<=1'b0; end
        else if (divTick==8'd249) begin divTick<=8'd0; tick<=1'b1; end
        else begin divTick<=divTick+8'd1; tick<=1'b0; end
    end

    // ---------- motor I2C ----------
    reg        arrancar;
    reg  [7:0] datoI2C;
    wire       listoI2C;
    MotorI2C motor (
        .clk(clk), .rst(rst), .tick(tick), .arrancar(arrancar),
        .dato(datoI2C), .listo(listoI2C), .sda(sda), .scl(scl)
    );

    // ---------- empaqueta un nibble para el PCF8574 ----------
    // {D7..D4 , Backlight=1 , EN , RW=0 , RS}
    function [7:0] pcf;
        input [3:0] nib; input en; input rs;
        pcf = {nib, 1'b1, en, 1'b0, rs};
    endfunction

    // ---------- ROM de mensajes (16 caracteres, fila 1) ----------
    function [7:0] letra;
        input [1:0] msg; input [3:0] idx;
        begin
          case (msg)
            2'd0: case (idx)  // "Ingresar Clave"
                0:letra="I";1:letra="n";2:letra="g";3:letra="r";4:letra="e";
                5:letra="s";6:letra="a";7:letra="r";8:letra=" ";9:letra="C";
                10:letra="l";11:letra="a";12:letra="v";13:letra="e";
                default:letra=" "; endcase
            2'd1: case (idx)  // "Desbloqueado"
                0:letra="D";1:letra="e";2:letra="s";3:letra="b";4:letra="l";
                5:letra="o";6:letra="q";7:letra="u";8:letra="e";9:letra="a";
                10:letra="d";11:letra="o";default:letra=" "; endcase
            2'd2: case (idx)  // "Cambiar Clave"
                0:letra="C";1:letra="a";2:letra="m";3:letra="b";4:letra="i";
                5:letra="a";6:letra="r";7:letra=" ";8:letra="C";9:letra="l";
                10:letra="a";11:letra="v";12:letra="e";default:letra=" "; endcase
            default: letra=" ";
          endcase
        end
    endfunction

    // ---------- nibbles de inicializacion ----------
    // 3,3,3 (despierta) | 2 (pasa a 4 bits) | 2,8 (0x28) |
    // 0,C (0x0C display on) | 0,1 (0x01 clear) | 0,6 (0x06 entry)
    function [3:0] nibbleInit;
        input [3:0] i;
        case (i)
          0:nibbleInit=4'h3; 1:nibbleInit=4'h3; 2:nibbleInit=4'h3;
          3:nibbleInit=4'h2;
          4:nibbleInit=4'h2; 5:nibbleInit=4'h8;
          6:nibbleInit=4'h0; 7:nibbleInit=4'hF;
          8:nibbleInit=4'h0; 9:nibbleInit=4'h1;
          10:nibbleInit=4'h0; 11:nibbleInit=4'h6;
          default:nibbleInit=4'h0;
        endcase
    endfunction

    // ---------- estados ----------
    localparam BOOT=0, INI_PREP=1, INI_DEL=2, OCIO=3, REF_PREP=4, REF_NEXT=5,
               BYTE_HI=6, BYTE_LO=7, NIB_0=8, NIB_1=9, NIB_DLY=10,
               PCF_ARR=11, PCF_BUSY=12, PCF_DONE=13, ESPERA=14;

    reg [3:0]  est;
    reg [3:0]  retByte, retNib, retEsp, retPcf;
    reg [3:0]  iniIdx;
    reg [5:0]  pasoRef;
    reg [7:0]  byteEnv;
    reg        rsEnv;
    reg [3:0]  nibEnv;
    reg        rsNib;
    reg        cmdLatchR, cmdLatchE;
    reg [21:0] contDelay, metaDelay;

    // accion de refresco segun el paso (combinacional):
    //  0      -> comando 0x80 (inicio fila 1)
    //  1..16  -> 16 caracteres del mensaje (fila 1)
    //  17     -> comando 0xC0 (inicio fila 2)
    //  18..33 -> 16 espacios (limpia fila 2)
    //  34     -> comando 0xC0 (reposiciona el cursor en la fila 2)
    reg [7:0] accByte; reg accRs;
    always @(*) begin
        if (pasoRef==6'd0)       begin accByte=8'h80;                  accRs=1'b0; end
        else if (pasoRef<=6'd16) begin accByte=letra(selMsg, pasoRef-6'd1); accRs=1'b1; end
        else if (pasoRef==6'd17) begin accByte=8'hC0;                  accRs=1'b0; end
        else if (pasoRef<=6'd33) begin accByte=8'h20;                  accRs=1'b1; end
        else                     begin accByte=8'hC0;                  accRs=1'b0; end
    end

    assign libre = (est==OCIO) && !cmdLatchR && !cmdLatchE;

    always @(posedge clk or posedge rst) begin
        if (rst) begin
            est<=BOOT; arrancar<=1'b0; datoI2C<=8'h00;
            iniIdx<=4'd0; pasoRef<=6'd0; byteEnv<=8'h00; rsEnv<=1'b0;
            nibEnv<=4'h0; rsNib<=1'b0;
            cmdLatchR<=1'b0; cmdLatchE<=1'b0; contDelay<=22'd0; metaDelay<=22'd0;
            retByte<=OCIO; retNib<=OCIO; retEsp<=OCIO; retPcf<=OCIO;
        end else begin
            arrancar <= 1'b0;                    // pulso por defecto en 0
            if (cmdRefrescar) cmdLatchR <= 1'b1; // captura ordenes del top
            if (cmdEscribir)  cmdLatchE <= 1'b1;

            case (est)
            //---------- espera de encendido (~50 ms) ----------
            BOOT: begin
                if (contDelay >= 22'd2_500_000) begin
                    contDelay<=22'd0; iniIdx<=4'd0; est<=INI_PREP;
                end else contDelay <= contDelay + 22'd1;
            end
            //---------- inicializacion: envia cada nibble ----------
            INI_PREP: begin
                nibEnv<=nibbleInit(iniIdx); rsNib<=1'b0;   // son comandos
                retNib<=INI_DEL; est<=NIB_0;
            end
            INI_DEL: begin
                metaDelay<=22'd150_000;                    // ~3 ms entre pasos
                contDelay<=22'd0;
                retEsp <= (iniIdx==4'd11) ? OCIO : INI_PREP;
                if (iniIdx!=4'd11) iniIdx <= iniIdx + 4'd1;
                est<=ESPERA;
            end
            //---------- ocioso: espera orden del modulo principal ----------
            OCIO: begin
                if (cmdLatchR) begin
                    cmdLatchR<=1'b0; pasoRef<=6'd0; est<=REF_PREP;
                end else if (cmdLatchE) begin
                    cmdLatchE<=1'b0; byteEnv<=caracter; rsEnv<=1'b1;
                    retByte<=OCIO; est<=BYTE_HI;
                end
            end
            //---------- refresco: recorre los 35 pasos ----------
            REF_PREP: begin
                byteEnv<=accByte; rsEnv<=accRs;
                retByte<=REF_NEXT; est<=BYTE_HI;
            end
            REF_NEXT: begin
                if (pasoRef==6'd34) est<=OCIO;
                else begin pasoRef<=pasoRef+6'd1; est<=REF_PREP; end
            end
            //---------- enviar un BYTE = nibble alto + nibble bajo ----------
            BYTE_HI: begin
                nibEnv<=byteEnv[7:4]; rsNib<=rsEnv;
                retNib<=BYTE_LO; est<=NIB_0;
            end
            BYTE_LO: begin
                nibEnv<=byteEnv[3:0]; rsNib<=rsEnv;
                retNib<=retByte; est<=NIB_0;
            end
            //---------- enviar un NIBBLE = PCF(EN=1) + PCF(EN=0) + retardo ----------
            NIB_0: begin datoI2C<=pcf(nibEnv,1'b1,rsNib); retPcf<=NIB_1;   est<=PCF_ARR; end
            NIB_1: begin datoI2C<=pcf(nibEnv,1'b0,rsNib); retPcf<=NIB_DLY; est<=PCF_ARR; end
            NIB_DLY: begin
                metaDelay<=22'd10000;                      // ~200 us tras el nibble
                contDelay<=22'd0;
                retEsp<=retNib; est<=ESPERA;
            end
            //---------- enviar 1 byte por el motor I2C ----------
            PCF_ARR:  begin arrancar<=1'b1; est<=PCF_BUSY; end
            PCF_BUSY: begin if (!listoI2C) est<=PCF_DONE; end   // arranco
            PCF_DONE: begin if (listoI2C)  est<=retPcf;  end    // termino
            //---------- retardo generico ----------
            ESPERA: begin
                if (contDelay >= metaDelay) est<=retEsp;
                else contDelay <= contDelay + 22'd1;
            end
            default: est<=OCIO;
            endcase
        end
    end
endmodule


//==============================================================
//  MODULO PRINCIPAL (TOP): CajaFuerte
//  Maquina de estados de los 3 estados pedidos.
//==============================================================
module top(
    input  wire       clk,        // 50 MHz
    input  wire       rst_n,        // reset (boton)

    output wire [3:0] filas,      // al teclado
    input  wire [3:0] columnas,   // del teclado

    inout  wire       sda,        // I2C (a la LCD via convertidor de nivel)
    output wire       scl,

    output reg        ledRojo,    // canal R del LED RGB
    output reg        ledVerde,   // canal G del LED RGB
    output reg        ledAzul,    // canal B del LED RGB
    output reg        servo,      // senal PWM hacia el servomotor MG996R
    output reg        buzzer,     // buzzer externo MH-FMD (PIN_80)

    // -------- RFID RC522 (SPI) --------
    output wire       rfidSck,    // SCK  -> RC522
    output wire       rfidMosi,   // MOSI -> RC522
    input  wire       rfidMiso,   // MISO <- RC522
    output wire       rfidCs,     // SDA/CS (activo en bajo) -> RC522
    output wire       rfidRst     // RST (activo en bajo) -> RC522
);
    
    // -------- teclado --------
    wire [3:0] codigoTecla; wire teclaValida; wire rst = ~rst_n;
    TecladoMatricial teclado (
        .clk(clk), .rst(rst), .filas(filas), .columnas(columnas),
        .codigoTecla(codigoTecla), .teclaValida(teclaValida)
    );

    // -------- LCD --------
    reg  [1:0] selMsg; reg cmdRefrescar, cmdEscribir; reg [7:0] caracter;
    wire       libre;
    ControladorLCD lcd (
        .clk(clk), .rst(rst), .selMsg(selMsg),
        .cmdRefrescar(cmdRefrescar), .cmdEscribir(cmdEscribir),
        .caracter(caracter), .libre(libre), .sda(sda), .scl(scl)
    );

    // -------- registros de clave y captura --------
    reg [3:0] clave0,clave1,clave2,clave3;   // clave guardada (por defecto 0000)
    reg [3:0] ing0,ing1,ing2,ing3;           // digitos ingresados
    reg [2:0] cont;                          // cuantos digitos van (0..4)
    reg [1:0] intentos;                      // 0,1,2,3 (3 = saturado, buzzer ON)
    reg       mostrado;                      // mensaje ya refrescado en el estado
    function [7:0] aAscii; input [3:0] d; aAscii = 8'h30 + d; endfunction

    // -------- estados --------
    localparam IngresarClave=2'd0, Desbloqueado=2'd1, CambiarClave=2'd2;
    reg [1:0] estado;

    // -------- servomotor MG996R: PWM 50 Hz (periodo de 20 ms) --------
    // A 50 MHz: 20 ms = 1,000,000 ciclos de reloj.
    //   1.5 ms (75,000 ciclos)  ->   0 grados (centro)        -> Ingresar Clave
    //   1.0 ms (50,000 ciclos)  -> -90 grados (todo izquierda) -> Desbloqueado
    localparam [19:0] PULSO_CERO = 20'd75_000;  // 1.5 ms ->   0 grados
    localparam [19:0] PULSO_IZQ  = 20'd50_000;  // 1.0 ms -> -90 grados (izquierda)

    reg [19:0] contadorPwm;   // cuenta el periodo de 20 ms
    reg [19:0] pulsoServo;    // ancho de pulso actual (lo decide la FSM principal)

    // Genera la onda PWM continuamente, sin importar el estado:
    // la salida 'servo' esta en alto mientras el contador sea menor
    // que 'pulsoServo', y en bajo el resto del periodo.
    always @(posedge clk or posedge rst) begin
        if (rst) begin
            contadorPwm <= 20'd0;
            servo       <= 1'b0;
        end else begin
            if (contadorPwm >= 20'd999_999) contadorPwm <= 20'd0;
            else                            contadorPwm <= contadorPwm + 20'd1;
            servo <= (contadorPwm < pulsoServo) ? 1'b1 : 1'b0;
        end
    end

    // -------- buzzer externo MH-FMD (modulo, disparo por nivel BAJO) --------
    // Este modulo trae un buzzer PASIVO: no tiene oscilador propio, asi que
    // con un nivel fijo solo hace "clic". Para que suene hay que entregarle
    // una FRECUENCIA. Como dispara por nivel bajo, en reposo dejamos el pin
    // en 1 (silencio) y, cuando 'buzzerOn'=1, generamos una onda cuadrada de
    // ~2.5 kHz que lo hace sonar (el pin baja a 0 en cada medio ciclo).
    //   frecuencia = 50 MHz / (2 * MITAD_TONO)
    //   10000 -> 2.5 kHz | 9260 -> ~2.7 kHz | 7150 -> ~3.5 kHz | 6250 -> 4 kHz
    localparam [13:0] MITAD_TONO = 14'd10000;
    reg        buzzerOn;       // intencion de la FSM (1 = alarma activa)
    reg [13:0] contTono;       // divisor para generar el tono
    always @(posedge clk or posedge rst) begin
        if (rst) begin
            contTono <= 14'd0; buzzer <= 1'b1;          // 1 = silencio (reposo)
        end else if (buzzerOn) begin
            if (contTono >= MITAD_TONO-14'd1) begin
                contTono <= 14'd0; buzzer <= ~buzzer;   // onda cuadrada -> suena
            end else contTono <= contTono + 14'd1;
        end else begin
            contTono <= 14'd0; buzzer <= 1'b1;          // silencio (nivel alto)
        end
    end

    //==========================================================
    //  INTEGRACION RFID RC522 (SPI)
    //==========================================================
    // Un solo maestro SPI es compartido por dos modulos:
    //   - rc522_init : configura el lector UNA vez al encender.
    //   - rc522_reader: sondea tarjetas de forma repetida.
    // Antes de que 'init_done'=1 el bus SPI lo maneja la init;
    // despues lo maneja el lector (MUX con init_done).

    wire        init_done;
    wire [7:0]  spi_rx;
    wire        spi_busy;
    // señales SPI que produce la init
    wire        i_spi_start, i_spi_hold_cs; wire [7:0] i_spi_tx;
    // señales SPI que produce el lector
    wire        r_spi_start, r_spi_hold_cs; wire [7:0] r_spi_tx;

    // MUX del bus SPI (init hasta terminar; luego, el lector)
    wire        spi_start   = init_done ? r_spi_start   : i_spi_start;
    wire        spi_hold_cs = init_done ? r_spi_hold_cs : i_spi_hold_cs;
    wire [7:0]  spi_tx      = init_done ? r_spi_tx      : i_spi_tx;

    spi_master_with_cs spi (
        .clk(clk), .rst(rst),
        .start(spi_start), .hold_cs(spi_hold_cs), .tx_data(spi_tx),
        .rx_data(spi_rx), .busy(spi_busy),
        .sck(rfidSck), .mosi(rfidMosi), .miso(rfidMiso), .cs(rfidCs)
    );

    // Disparo unico de la inicializacion (un pulso tras el reset)
    reg init_start, initArrancado;
    always @(posedge clk or posedge rst) begin
        if (rst) begin init_start<=1'b0; initArrancado<=1'b0; end
        else begin
            init_start <= 1'b0;
            if (!initArrancado) begin init_start<=1'b1; initArrancado<=1'b1; end
        end
    end

    rc522_init init_rfid (
        .clk(clk), .rst(rst), .start(init_start), .done(init_done),
        .mfrc_rst(rfidRst),
        .spi_start(i_spi_start), .spi_hold_cs(i_spi_hold_cs),
        .spi_tx(i_spi_tx), .spi_busy(spi_busy)
    );

    // Sondeo periodico del lector (~50 ms) una vez inicializado
    wire        rd_done, card_present, uid_valid, card_detected;
    wire [31:0] uid;
    reg         rd_start, rdBusy;
    reg [21:0]  pollTimer;
    always @(posedge clk or posedge rst) begin
        if (rst) begin rd_start<=1'b0; rdBusy<=1'b0; pollTimer<=22'd0; end
        else begin
            rd_start <= 1'b0;
            if (!init_done) begin pollTimer<=22'd0; rdBusy<=1'b0; end
            else if (rdBusy) begin
                if (rd_done) rdBusy<=1'b0;               // termino el intento de lectura
            end else if (pollTimer >= 22'd2_500_000) begin // ~50 ms entre sondeos
                pollTimer<=22'd0; rd_start<=1'b1; rdBusy<=1'b1;
            end else pollTimer <= pollTimer + 22'd1;
        end
    end

    rc522_reader #(.MATCH_ANY(1)) reader_rfid (  // detecta cualquier tarjeta; el
        .clk(clk), .rst(rst), .start(rd_start), .done(rd_done),  // filtro va abajo
        .card_present(card_present), .uid_valid(uid_valid), .uid(uid),
        .card_detected(card_detected),
        .spi_start(r_spi_start), .spi_hold_cs(r_spi_hold_cs),
        .spi_tx(r_spi_tx), .spi_rx(spi_rx), .spi_busy(spi_busy)
    );

    // ---- UID autorizados (solo estas tarjetas desbloquean) ----
    // El UID que entrega el lector es {byte0,byte1,byte2,byte3} en el mismo
    // orden en que la tarjeta los envia. Si tus tarjetas no abrieran, es casi
    // seguro tema de ORDEN de bytes: invierte el UID (ver nota).
    localparam [31:0] UID_A = 32'h2A979404;
    localparam [31:0] UID_B = 32'h5C91D505;

    // Entrada 1/0 hacia el estado Ingresar Clave:
    // 'tarjetaOk' se pone en 1 solo si se lee una tarjeta cuyo UID coincide
    // con UID_A o UID_B, y solo MIENTRAS se esta ingresando la clave. Se
    // limpia sola al salir del estado (una tarjeta leida en otro estado no
    // desbloquea despues).
    reg tarjetaOk;
    always @(posedge clk or posedge rst) begin
        if (rst) tarjetaOk <= 1'b0;
        else if (estado != IngresarClave) tarjetaOk <= 1'b0;   // 0 = sigue igual
        else if (card_detected && (uid==UID_A || uid==UID_B))
                                          tarjetaOk <= 1'b1;    // 1 = desbloquear
    end

    always @(posedge clk or posedge rst) begin
        if (rst) begin
            estado<=IngresarClave;
            clave0<=4'd0;clave1<=4'd0;clave2<=4'd0;clave3<=4'd0;
            ing0<=4'd0;ing1<=4'd0;ing2<=4'd0;ing3<=4'd0;
            cont<=3'd0; intentos<=2'd0; mostrado<=1'b0;
            ledRojo<=1'b0;ledVerde<=1'b0;ledAzul<=1'b0;buzzerOn<=1'b0;
            pulsoServo<=PULSO_CERO;   // el servo arranca en 0 grados (centro)
            selMsg<=2'd0; cmdRefrescar<=1'b0; cmdEscribir<=1'b0; caracter<=8'h00;
        end else begin
            cmdRefrescar<=1'b0; cmdEscribir<=1'b0;   // pulsos por defecto en 0

            case (estado)
            //==========================================================
            //  ESTADO 1: INGRESAR CLAVE  (inicial)
            //==========================================================
            IngresarClave: begin
                pulsoServo<=PULSO_CERO; ledAzul<=1'b0;   // servo en 0 grados (centro)
                // color del RGB / buzzer segun los intentos fallidos
                case (intentos)
                  2'd0: begin ledVerde<=1'b1; ledRojo<=1'b0; buzzerOn<=1'b0; end // verde
                  2'd1: begin ledVerde<=1'b1; ledRojo<=1'b1; buzzerOn<=1'b0; end // amarillo
                  2'd2: begin ledVerde<=1'b0; ledRojo<=1'b1; buzzerOn<=1'b0; end // rojo
                  default: begin ledVerde<=1'b0; ledRojo<=1'b1; buzzerOn<=1'b1; end // rojo+buzzer
                endcase

                selMsg<=IngresarClave;
                if (tarjetaOk) begin
                    // entrada RFID en 1 -> desbloquea (igual que clave correcta)
                    intentos<=2'd0; mostrado<=1'b0; estado<=Desbloqueado;
                end else if (!mostrado && libre) begin
                    cmdRefrescar<=1'b1; mostrado<=1'b1; cont<=3'd0;
                end else if (mostrado && libre) begin
                    // captura de 4 digitos (solo 0..9, sin borrar)
                    if (teclaValida && cont<3'd4 && codigoTecla<=4'd9) begin
                        case (cont)
                          0:ing0<=codigoTecla;1:ing1<=codigoTecla;
                          2:ing2<=codigoTecla;3:ing3<=codigoTecla; endcase
                        caracter<=aAscii(codigoTecla); cmdEscribir<=1'b1;
                        cont<=cont+3'd1;
                    end
                    // al completar los 4 digitos, validar
                    if (cont==3'd4) begin
                        cont<=3'd0;
                        if (ing0==clave0 && ing1==clave1 &&
                            ing2==clave2 && ing3==clave3) begin
                            intentos<=2'd0; mostrado<=1'b0; estado<=Desbloqueado;
                        end else begin
                            if (intentos<2'd3) intentos<=intentos+2'd1;
                            mostrado<=1'b0;     // re-refresca: borra la fila 2
                        end
                    end
                end
            end
            //==========================================================
            //  ESTADO 2: DESBLOQUEADO
            //==========================================================
            Desbloqueado: begin
                ledVerde<=1'b1; ledRojo<=1'b0; ledAzul<=1'b0;
                buzzerOn<=1'b0; pulsoServo<=PULSO_IZQ;   // servo gira 90 a la izquierda

                selMsg<=Desbloqueado;
                if (!mostrado && libre) begin
                    cmdRefrescar<=1'b1; mostrado<=1'b1;
                end else if (mostrado && libre) begin
                    if (teclaValida && codigoTecla==4'd10) begin        // 'A'
                        mostrado<=1'b0; intentos<=2'd0; estado<=IngresarClave;
                    end else if (teclaValida && codigoTecla==4'd14) begin // '*'
                        mostrado<=1'b0; cont<=3'd0; estado<=CambiarClave;
                    end
                end
            end
            //==========================================================
            //  ESTADO 3: CAMBIAR CLAVE
            //==========================================================
            CambiarClave: begin
                ledVerde<=1'b0; ledRojo<=1'b0; ledAzul<=1'b1;   // LED RGB en AZUL
                buzzerOn<=1'b0;                                    // servo: mantiene su posicion

                selMsg<=CambiarClave;
                if (!mostrado && libre) begin
                    cmdRefrescar<=1'b1; mostrado<=1'b1; cont<=3'd0;
                end else if (mostrado && libre) begin
                    // los primeros 4 numeros son la nueva clave (sin borrar)
                    if (teclaValida && cont<3'd4 && codigoTecla<=4'd9) begin
                        case (cont)
                          0:clave0<=codigoTecla;1:clave1<=codigoTecla;
                          2:clave2<=codigoTecla;3:clave3<=codigoTecla; endcase
                        caracter<=aAscii(codigoTecla); cmdEscribir<=1'b1;
                        cont<=cont+3'd1;
                    end
                    if (cont==3'd4) begin
                        cont<=3'd0; mostrado<=1'b0; intentos<=2'd0;
                        estado<=IngresarClave;     // vuelve al estado inicial
                    end
                end
            end
            default: estado<=IngresarClave;
            endcase
        end
    end
endmodule


// =========================================================================
//  MAESTRO SPI (Modo 0, 8 bits, CS automatico) -- MODIFICADO
//  Se le agrego la entrada 'hold_cs': cuando vale 1, el CS se MANTIENE
//  abajo despues de enviar el byte (necesario para los accesos de 2 bytes
//  del RC522: [direccion] + [dato] en la misma trama con CS abajo).
//  El resto es identico a tu version probada.
// =========================================================================
module spi_master_with_cs (
    input  wire       clk,
    input  wire       rst,
    input  wire       start,
    input  wire       hold_cs,     // 1 = mantener CS abajo tras el byte
    input  wire [7:0] tx_data,
    output reg  [7:0] rx_data,
    output reg        busy,
    output reg        sck,
    output reg        mosi,
    input  wire       miso,
    output reg        cs
);
    localparam IDLE = 3'b000, CS_FALL = 3'b001, TRANSFER = 3'b010, CS_RISE = 3'b011;

    reg [2:0] state;
    reg [4:0] clk_count;
    reg [2:0] bit_count;
    reg [7:0] tx_reg;
    reg [7:0] rx_reg;
    reg       spi_clk_edge;
    reg       hold_reg;      // recuerda si hay que mantener CS abajo

    // Divisor de frecuencia (igual): 50MHz/25 -> 2MHz flancos -> 1MHz SCK
    always @(posedge clk or posedge rst) begin
        if (rst) begin
            clk_count    <= 5'd0;
            spi_clk_edge <= 1'b0;
        end else if (state != IDLE) begin
            if (clk_count == 5'd24) begin
                clk_count    <= 5'd0;
                spi_clk_edge <= 1'b1;
            end else begin
                clk_count    <= clk_count + 1'b1;
                spi_clk_edge <= 1'b0;
            end
        end else begin
            clk_count    <= 5'd0;
            spi_clk_edge <= 1'b0;
        end
    end

    always @(posedge clk or posedge rst) begin
        if (rst) begin
            state     <= IDLE;
            busy      <= 1'b0;
            sck       <= 1'b0;
            mosi      <= 1'b0;
            cs        <= 1'b1;
            bit_count <= 3'd0;
            tx_reg    <= 8'd0;
            rx_reg    <= 8'd0;
            rx_data   <= 8'd0;
            hold_reg  <= 1'b0;
        end else begin
            case (state)

                IDLE: begin
                    busy <= 1'b0;
                    sck  <= 1'b0;
                    cs   <= hold_reg ? 1'b0 : 1'b1;   // mantiene CS si venimos de un hold
                    if (start) begin
                        busy     <= 1'b1;
                        tx_reg   <= tx_data;
                        hold_reg <= hold_cs;          // latch del hold para este byte
                        cs       <= 1'b0;             // asegura CS abajo
                        state    <= CS_FALL;
                    end
                end

                CS_FALL: begin
                    cs <= 1'b0;
                    if (spi_clk_edge) begin
                        mosi  <= tx_reg[7];
                        state <= TRANSFER;
                    end
                end

                TRANSFER: begin
                    if (spi_clk_edge) begin
                        sck <= ~sck;
                        if (~sck) begin
                            rx_reg <= {rx_reg[6:0], miso};   // flanco de subida: lee MISO
                        end else begin
                            tx_reg    <= {tx_reg[6:0], 1'b0}; // flanco de bajada: saca MOSI
                            bit_count <= bit_count + 1'b1;
                            if (bit_count == 3'd7) state <= CS_RISE;
                            else mosi <= tx_reg[6];
                        end
                    end
                end

                CS_RISE: begin
                    if (spi_clk_edge) begin
                        sck     <= 1'b0;
                        mosi    <= 1'b0;
                        cs      <= hold_reg ? 1'b0 : 1'b1;   // mantiene o sube CS
                        rx_data <= rx_reg;
                        state   <= IDLE;
                    end
                end

                default: state <= IDLE;
            endcase
        end
    end
endmodule
// =========================================================================
// MODULO: rc522_init
// Inicializa el lector RFID MFRC522 (RC522) y lo deja listo para leer.
//
// Que hace, en orden:
//   1. Pulso de reset fisico por el pin RST del RC522 (activo bajo).
//   2. Espera el arranque del oscilador (~50 ms, hoja de datos 8.8.2).
//   3. Soft reset por SPI: CommandReg(0x01) = 0x0F. Espera ~50 ms.
//   4. Escribe los registros de configuracion (timer, ASK, CRC, ganancia).
//   5. Enciende la antena (TxControlReg = 0x83). Levanta 'done'.
//
// No instancia el maestro SPI: lo maneja por handshake para poder COMPARTIRLO
// despues con el modulo lector de UID. Cada escritura de registro son 2 bytes
// con CS abajo: [ (reg<<1) con bit7=0 ]  +  [ dato ].
//
// ------ EJEMPLO DE CONEXION EN EL TOP-LEVEL ------
//   spi_master_with_cs spi (
//       .clk(clk), .rst(rst),
//       .start(spi_start), .hold_cs(spi_hold_cs), .tx_data(spi_tx),
//       .rx_data(spi_rx), .busy(spi_busy),
//       .sck(SCK), .mosi(MOSI), .miso(MISO), .cs(CS) );   // -> pines RC522
//
//   rc522_init init (
//       .clk(clk), .rst(rst), .start(init_start), .done(init_done),
//       .mfrc_rst(RST),                                   // -> pin RST RC522
//       .spi_start(spi_start), .spi_hold_cs(spi_hold_cs),
//       .spi_tx(spi_tx), .spi_busy(spi_busy) );
// =========================================================================

module rc522_init #(
    // Retardos en ciclos de reloj (por defecto a 50 MHz). En simulacion se
    // pueden reducir con parametros para no esperar millones de ciclos.
    parameter integer RST_LOW_CYCLES  = 50_000,     // ~1  ms  (RST fisico abajo)
    parameter integer OSC_WAIT_CYCLES = 2_500_000,  // ~50 ms  (arranque oscilador)
    parameter integer SR_WAIT_CYCLES  = 2_500_000   // ~50 ms  (tras soft reset)
)(
    input  wire       clk,          // reloj principal (50 MHz)
    input  wire       rst,          // reset global FPGA (activo alto)
    input  wire       start,        // pulso de 1 ciclo: arranca la inicializacion
    output reg        done,         // '1' cuando el RC522 quedo listo
    output reg        mfrc_rst,     // -> pin RST del RC522 (activo bajo)

    // Handshake con spi_master_with_cs (compartido)
    output reg        spi_start,    // pulso para enviar un byte
    output reg        spi_hold_cs,  // 1 = mantener CS abajo tras el byte
    output reg [7:0]  spi_tx,       // byte a enviar
    input  wire       spi_busy      // '1' mientras el SPI transmite
);

    // ---------------------------------------------------------------------
    // Estados
    // ---------------------------------------------------------------------
    localparam S_IDLE     = 4'd0;
    localparam S_RST_LOW  = 4'd1;   // RST fisico abajo
    localparam S_OSC_WAIT = 4'd2;   // espera oscilador
    localparam S_SR_DATA  = 4'd3;   // segundo byte del soft reset
    localparam S_SR_WAIT  = 4'd4;   // espera tras soft reset
    localparam S_TBL_ADDR = 4'd5;   // byte de direccion del registro
    localparam S_TBL_DATA = 4'd6;   // byte de dato del registro
    localparam S_TBL_NEXT = 4'd7;   // avanzar al siguiente registro
    localparam S_SND_ISS  = 4'd8;   // subrutina: emitir start
    localparam S_SND_BUSY = 4'd9;   // subrutina: esperar busy=1
    localparam S_SND_DONE = 4'd10;  // subrutina: esperar busy=0
    localparam S_DONE     = 4'd11;

    localparam LAST_IDX = 4'd10;    // indice de la ultima escritura (11 entradas: 0..10)

    reg [3:0]  state, after_send;
    reg [23:0] dcnt;
    reg [3:0]  idx;
    reg [7:0]  snd_data;            // byte que la subrutina de envio va a mandar
    reg        snd_hold;            // hold_cs para ese byte

    // ---------------------------------------------------------------------
    // Tabla de configuracion (registro, valor). Se escribe tras el soft reset.
    // ---------------------------------------------------------------------
    function [7:0] tbl_reg(input [3:0] i);
        case (i)
            4'd0 : tbl_reg = 8'h12;  // TxModeReg      -> 0x00 (velocidad/framing TX)
            4'd1 : tbl_reg = 8'h13;  // RxModeReg      -> 0x00 (velocidad/framing RX)
            4'd2 : tbl_reg = 8'h24;  // ModWidthReg    -> 0x26
            4'd3 : tbl_reg = 8'h2A;  // TModeReg       -> 0x80 (TAuto=1)
            4'd4 : tbl_reg = 8'h2B;  // TPrescalerReg  -> 0xA9 (f_timer=40kHz)
            4'd5 : tbl_reg = 8'h2C;  // TReloadRegH    -> 0x03  } timeout
            4'd6 : tbl_reg = 8'h2D;  // TReloadRegL    -> 0xE8  } ~25 ms
            4'd7 : tbl_reg = 8'h15;  // TxASKReg       -> 0x40 (100% ASK)
            4'd8 : tbl_reg = 8'h11;  // ModeReg        -> 0x3D (CRC preset 0x6363)
            4'd9 : tbl_reg = 8'h26;  // RFCfgReg       -> 0x70 (ganancia RX max)
            4'd10: tbl_reg = 8'h14;  // TxControlReg   -> 0x83 (antena ON)
            default: tbl_reg = 8'h00;
        endcase
    endfunction

    function [7:0] tbl_val(input [3:0] i);
        case (i)
            4'd0 : tbl_val = 8'h00;
            4'd1 : tbl_val = 8'h00;
            4'd2 : tbl_val = 8'h26;
            4'd3 : tbl_val = 8'h80;
            4'd4 : tbl_val = 8'hA9;
            4'd5 : tbl_val = 8'h03;
            4'd6 : tbl_val = 8'hE8;
            4'd7 : tbl_val = 8'h40;
            4'd8 : tbl_val = 8'h3D;
            4'd9 : tbl_val = 8'h70;
            4'd10: tbl_val = 8'h83;
            default: tbl_val = 8'h00;
        endcase
    endfunction

    // ---------------------------------------------------------------------
    // FSM
    // ---------------------------------------------------------------------
    always @(posedge clk or posedge rst) begin
        if (rst) begin
            state       <= S_IDLE;
            after_send  <= S_IDLE;
            done        <= 1'b0;
            mfrc_rst    <= 1'b1;    // RC522 fuera de reset por defecto
            spi_start   <= 1'b0;
            spi_hold_cs <= 1'b0;
            spi_tx      <= 8'h00;
            dcnt        <= 24'd0;
            idx         <= 4'd0;
            snd_data    <= 8'h00;
            snd_hold    <= 1'b0;
        end else begin
            spi_start <= 1'b0;      // por defecto: sin pulso (se activa solo en S_SND_ISS)

            case (state)

                // ---- Reposo ----
                S_IDLE: begin
                    done     <= 1'b0;
                    mfrc_rst <= 1'b1;
                    if (start) begin
                        dcnt  <= 24'd0;
                        state <= S_RST_LOW;
                    end
                end

                // ---- Reset fisico (RST abajo) ----
                S_RST_LOW: begin
                    mfrc_rst <= 1'b0;
                    if (dcnt == RST_LOW_CYCLES-1) begin
                        dcnt     <= 24'd0;
                        mfrc_rst <= 1'b1;          // libera el reset
                        state    <= S_OSC_WAIT;
                    end else dcnt <= dcnt + 1'b1;
                end

                // ---- Espera de arranque del oscilador ----
                S_OSC_WAIT: begin
                    if (dcnt == OSC_WAIT_CYCLES-1) begin
                        dcnt       <= 24'd0;
                        // soft reset: CommandReg(0x01)=0x0F -> byte de direccion = 0x01<<1
                        snd_data   <= {7'h01, 1'b0}; // = 0x02  (bit7=0: escritura)
                        snd_hold   <= 1'b1;
                        after_send <= S_SR_DATA;
                        state      <= S_SND_ISS;
                    end else dcnt <= dcnt + 1'b1;
                end

                // ---- Segundo byte del soft reset (el dato 0x0F) ----
                S_SR_DATA: begin
                    snd_data   <= 8'h0F;   // comando SoftReset
                    snd_hold   <= 1'b0;    // cierra la transaccion (CS sube)
                    after_send <= S_SR_WAIT;
                    state      <= S_SND_ISS;
                end

                // ---- Espera tras soft reset ----
                S_SR_WAIT: begin
                    if (dcnt == SR_WAIT_CYCLES-1) begin
                        dcnt  <= 24'd0;
                        idx   <= 4'd0;
                        state <= S_TBL_ADDR;
                    end else dcnt <= dcnt + 1'b1;
                end

                // ---- Escritura de registro: byte de direccion ----
                S_TBL_ADDR: begin
                    snd_data   <= tbl_reg(idx) << 1;         // (reg<<1), bit7=0 -> escritura
                    snd_hold   <= 1'b1;                      // mantiene CS abajo
                    after_send <= S_TBL_DATA;
                    state      <= S_SND_ISS;
                end

                // ---- Escritura de registro: byte de dato ----
                S_TBL_DATA: begin
                    snd_data   <= tbl_val(idx);
                    snd_hold   <= 1'b0;                      // cierra la transaccion
                    after_send <= S_TBL_NEXT;
                    state      <= S_SND_ISS;
                end

                // ---- Siguiente registro o fin ----
                S_TBL_NEXT: begin
                    if (idx == LAST_IDX) state <= S_DONE;
                    else begin
                        idx   <= idx + 1'b1;
                        state <= S_TBL_ADDR;
                    end
                end

                // =============================================================
                //  SUBRUTINA: enviar 1 byte por SPI (usa snd_data / snd_hold)
                //  Al terminar salta a 'after_send'.
                // =============================================================
                S_SND_ISS: begin
                    spi_tx      <= snd_data;
                    spi_hold_cs <= snd_hold;
                    spi_start   <= 1'b1;       // pulso de 1 ciclo
                    state       <= S_SND_BUSY;
                end

                S_SND_BUSY: begin
                    if (spi_busy) state <= S_SND_DONE;  // el SPI ya arranco
                end

                S_SND_DONE: begin
                    if (!spi_busy) state <= after_send; // byte terminado
                end

                // ---- Listo ----
                S_DONE: begin
                    done     <= 1'b1;
                    mfrc_rst <= 1'b1;
                end

                default: state <= S_IDLE;
            endcase
        end
    end
endmodule
// =========================================================================
// MODULO: rc522_reader
// Lee una tarjeta MIFARE (Type A) con el MFRC522 usando el maestro SPI:
//   1. REQA (0x26)               -> detecta si hay una tarjeta en el campo.
//   2. Anticolision CL1 (0x93,0x20) -> lee el UID de 4 bytes + BCC.
//   3. Comprueba el BCC y decide 'card_detected':
//        - MATCH_ANY = 1 : se activa con CUALQUIER tarjeta.
//        - MATCH_ANY = 0 : se activa solo si el UID == TARGET_UID.
//
// Para cambiar a "tarjeta especifica" en el futuro: poner MATCH_ANY=0 y
// TARGET_UID con el UID de la tarjeta (mismo orden en que sale 'uid').
//
// Se dispara con un pulso en 'start' (el top lo llama periodicamente).
// Comparte el mismo spi_master_with_cs que la init (via handshake).
//
// Nota: maneja UID de 4 bytes (una cascada). Tarjetas con UID de 7 bytes
// requeririan cascada nivel 2 (mejora futura). Para "presencia" da igual.
// =========================================================================

module rc522_reader #(
    parameter         MATCH_ANY  = 1,                 // 1 = cualquiera, 0 = comparar UID
    parameter [31:0]  TARGET_UID = 32'h00000000,      // UID objetivo si MATCH_ANY=0
    parameter integer POLL_MAX   = 20000              // tope de sondeo del IRQ (seguridad)
)(
    input  wire        clk,
    input  wire        rst,
    input  wire        start,          // pulso: intenta leer una tarjeta
    output reg         done,           // pulso 1 ciclo: termino el intento
    output reg         card_present,   // hubo respuesta a REQA (sticky hasta el siguiente start)
    output reg         uid_valid,      // se leyo un UID valido (BCC correcto) (sticky)
    output reg [31:0]  uid,            // UID leido, 4 bytes (sticky)
    output reg         card_detected,  // pulso 1 ciclo: cumple el criterio (any / match)

    // Handshake con spi_master_with_cs (compartido, ver MUX en el top)
    output reg         spi_start,
    output reg         spi_hold_cs,
    output reg [7:0]   spi_tx,
    input  wire [7:0]  spi_rx,
    input  wire        spi_busy
);

    // ---- Registros del MFRC522 ----
    localparam [7:0] REG_COMMAND   = 8'h01;
    localparam [7:0] REG_COMIRQ    = 8'h04;
    localparam [7:0] REG_ERROR     = 8'h06;
    localparam [7:0] REG_FIFODATA  = 8'h09;
    localparam [7:0] REG_FIFOLEVEL = 8'h0A;
    localparam [7:0] REG_BITFRAMING= 8'h0D;

    // ---- Comandos ----
    localparam [7:0] CMD_IDLE      = 8'h00;
    localparam [7:0] CMD_TRANSCV   = 8'h0C;
    // ---- Comandos a la tarjeta ----
    localparam [7:0] PICC_REQA     = 8'h26;   // frame corto de 7 bits
    localparam [7:0] PICC_ANTI1    = 8'h93;   // anticolision cascada 1
    localparam [7:0] PICC_NVB20    = 8'h20;   // NVB = 0x20 (2 bytes validos)

    // ---- Estados ----
    localparam S_IDLE        = 5'd0;
    localparam S_REQA_DONE   = 5'd2;
    localparam S_ANTI_DONE   = 5'd3;
    localparam S_FINISH      = 5'd4;
    localparam S_TXV_IDLE    = 5'd5;
    localparam S_TXV_CLRIRQ  = 5'd6;
    localparam S_TXV_FLUSH   = 5'd7;
    localparam S_TXV_FIFO0   = 5'd8;
    localparam S_TXV_FIFO1   = 5'd9;
    localparam S_TXV_BITF    = 5'd10;
    localparam S_TXV_CMDTR   = 5'd11;
    localparam S_TXV_START   = 5'd12;
    localparam S_TXV_POLL    = 5'd13;
    localparam S_TXV_POLLCHK = 5'd14;
    localparam S_TXV_RDERR   = 5'd15;
    localparam S_TXV_ERRCHK  = 5'd16;
    localparam S_TXV_RDLEN   = 5'd17;
    localparam S_TXV_LENCHK  = 5'd18;
    localparam S_TXV_RDFIFO  = 5'd19;
    localparam S_TXV_RDFIFOST= 5'd20;
    localparam S_TXV_STOPCLR = 5'd21;
    localparam S_WR_A        = 5'd22;
    localparam S_WR_D        = 5'd23;
    localparam S_RD_A        = 5'd24;
    localparam S_RD_D        = 5'd25;
    localparam S_SND_ISS     = 5'd26;
    localparam S_SND_BUSY    = 5'd27;
    localparam S_SND_WT      = 5'd28;

    reg [4:0]  state, after_snd, after_reg, after_txv;

    // Subrutina de acceso a registro
    reg [7:0]  reg_addr, reg_data;
    // Subrutina de envio de byte
    reg [7:0]  snd_data;
    reg        snd_hold;
    reg [7:0]  rx_cap;              // ultimo byte recibido por SPI

    // Parametros/resultados del transceive
    reg [7:0]  txv_tx0, txv_tx1;
    reg [1:0]  txv_len;
    reg [7:0]  txv_bits;
    reg        txv_err, txv_timeout;
    reg [3:0]  txv_rxlen;
    reg [7:0]  rxbuf [0:4];
    reg [2:0]  ridx;
    reg [15:0] pollcnt;

    wire [31:0] uid_read = {rxbuf[0], rxbuf[1], rxbuf[2], rxbuf[3]};
    wire        bcc_ok   = ((rxbuf[0]^rxbuf[1]^rxbuf[2]^rxbuf[3]) == rxbuf[4]);

    always @(posedge clk or posedge rst) begin
        if (rst) begin
            state         <= S_IDLE;
            after_snd     <= S_IDLE;
            after_reg     <= S_IDLE;
            after_txv     <= S_IDLE;
            done          <= 1'b0;
            card_present  <= 1'b0;
            uid_valid     <= 1'b0;
            uid           <= 32'h0;
            card_detected <= 1'b0;
            spi_start     <= 1'b0;
            spi_hold_cs   <= 1'b0;
            spi_tx        <= 8'h00;
            reg_addr      <= 8'h00;
            reg_data      <= 8'h00;
            snd_data      <= 8'h00;
            snd_hold      <= 1'b0;
            rx_cap        <= 8'h00;
            txv_tx0       <= 8'h00;
            txv_tx1       <= 8'h00;
            txv_len       <= 2'd1;
            txv_bits      <= 8'h00;
            txv_err       <= 1'b0;
            txv_timeout   <= 1'b0;
            txv_rxlen     <= 4'd0;
            ridx          <= 3'd0;
            pollcnt       <= 16'd0;
        end else begin
            // valores por defecto (pulsos de 1 ciclo)
            spi_start     <= 1'b0;
            done          <= 1'b0;
            card_detected <= 1'b0;

            case (state)

                // ================= SECUENCIA PRINCIPAL =================
                S_IDLE: begin
                    if (start) begin
                        card_present <= 1'b0;
                        uid_valid    <= 1'b0;
                        uid          <= 32'h0;
                        // preparar REQA (frame corto: TxLastBits = 7)
                        txv_tx0   <= PICC_REQA;
                        txv_len   <= 2'd1;
                        txv_bits  <= 8'h07;
                        after_txv <= S_REQA_DONE;
                        state     <= S_TXV_IDLE;
                    end
                end

                S_REQA_DONE: begin
                    if (txv_timeout || txv_err || (txv_rxlen < 4'd2)) begin
                        card_present <= 1'b0;      // no hay tarjeta
                        state        <= S_FINISH;
                    end else begin
                        card_present <= 1'b1;
                        // preparar anticolision CL1 (2 bytes, todos los bits validos)
                        txv_tx0   <= PICC_ANTI1;
                        txv_tx1   <= PICC_NVB20;
                        txv_len   <= 2'd2;
                        txv_bits  <= 8'h00;
                        after_txv <= S_ANTI_DONE;
                        state     <= S_TXV_IDLE;
                    end
                end

                S_ANTI_DONE: begin
                    if (txv_timeout || txv_err || (txv_rxlen < 4'd5) || !bcc_ok) begin
                        uid_valid <= 1'b0;
                        state     <= S_FINISH;
                    end else begin
                        uid_valid <= 1'b1;
                        uid       <= uid_read;
                        if (MATCH_ANY != 0)
                            card_detected <= 1'b1;                 // cualquier tarjeta
                        else if (uid_read == TARGET_UID)
                            card_detected <= 1'b1;                 // tarjeta especifica
                        state <= S_FINISH;
                    end
                end

                S_FINISH: begin
                    done  <= 1'b1;
                    state <= S_IDLE;
                end

                // ================= TRANSCEIVE =================
                S_TXV_IDLE:   begin reg_addr<=REG_COMMAND;   reg_data<=CMD_IDLE;    after_reg<=S_TXV_CLRIRQ; state<=S_WR_A; end
                S_TXV_CLRIRQ: begin reg_addr<=REG_COMIRQ;    reg_data<=8'h7F;       after_reg<=S_TXV_FLUSH;  state<=S_WR_A; end
                S_TXV_FLUSH:  begin reg_addr<=REG_FIFOLEVEL; reg_data<=8'h80;       after_reg<=S_TXV_FIFO0;  state<=S_WR_A; end
                S_TXV_FIFO0:  begin reg_addr<=REG_FIFODATA;  reg_data<=txv_tx0;
                                    after_reg <= (txv_len==2'd2) ? S_TXV_FIFO1 : S_TXV_BITF; state<=S_WR_A; end
                S_TXV_FIFO1:  begin reg_addr<=REG_FIFODATA;  reg_data<=txv_tx1;     after_reg<=S_TXV_BITF;   state<=S_WR_A; end
                S_TXV_BITF:   begin reg_addr<=REG_BITFRAMING;reg_data<=txv_bits;    after_reg<=S_TXV_CMDTR;  state<=S_WR_A; end
                S_TXV_CMDTR:  begin reg_addr<=REG_COMMAND;   reg_data<=CMD_TRANSCV; after_reg<=S_TXV_START;  state<=S_WR_A; end
                S_TXV_START:  begin reg_addr<=REG_BITFRAMING;reg_data<=(8'h80|txv_bits);
                                    after_reg<=S_TXV_POLL; pollcnt<=16'd0; state<=S_WR_A; end

                S_TXV_POLL:   begin reg_addr<=REG_COMIRQ; after_reg<=S_TXV_POLLCHK; state<=S_RD_A; end
                S_TXV_POLLCHK: begin
                    if (rx_cap & 8'h30) begin              // RxIRq | IdleIRq -> respondio
                        txv_timeout <= 1'b0;
                        state       <= S_TXV_RDERR;
                    end else if ((rx_cap & 8'h01) || (pollcnt >= POLL_MAX)) begin
                        txv_timeout <= 1'b1;               // TimerIRq -> sin tarjeta / timeout
                        txv_rxlen   <= 4'd0;
                        state       <= S_TXV_STOPCLR;
                    end else begin
                        pollcnt <= pollcnt + 16'd1;
                        state   <= S_TXV_POLL;
                    end
                end

                S_TXV_RDERR:  begin reg_addr<=REG_ERROR; after_reg<=S_TXV_ERRCHK; state<=S_RD_A; end
                S_TXV_ERRCHK: begin txv_err <= |(rx_cap & 8'h13); state<=S_TXV_RDLEN; end

                S_TXV_RDLEN:  begin reg_addr<=REG_FIFOLEVEL; after_reg<=S_TXV_LENCHK; state<=S_RD_A; end
                S_TXV_LENCHK: begin
                    txv_rxlen <= (rx_cap > 8'd5) ? 4'd5 : rx_cap[3:0];
                    ridx      <= 3'd0;
                    state     <= (rx_cap == 8'd0) ? S_TXV_STOPCLR : S_TXV_RDFIFO;
                end

                S_TXV_RDFIFO: begin reg_addr<=REG_FIFODATA; after_reg<=S_TXV_RDFIFOST; state<=S_RD_A; end
                S_TXV_RDFIFOST: begin
                    rxbuf[ridx] <= rx_cap;
                    if (ridx == (txv_rxlen - 4'd1)) state <= S_TXV_STOPCLR;
                    else begin ridx <= ridx + 3'd1; state <= S_TXV_RDFIFO; end
                end

                S_TXV_STOPCLR: begin  // limpia StartSend y vuelve al llamador
                    reg_addr<=REG_BITFRAMING; reg_data<=txv_bits; after_reg<=after_txv; state<=S_WR_A;
                end

                // ================= write_reg / read_reg =================
                S_WR_A: begin snd_data <= (reg_addr << 1);          snd_hold<=1'b1; after_snd<=S_WR_D;    state<=S_SND_ISS; end
                S_WR_D: begin snd_data <= reg_data;                 snd_hold<=1'b0; after_snd<=after_reg; state<=S_SND_ISS; end
                S_RD_A: begin snd_data <= (reg_addr << 1) | 8'h80;  snd_hold<=1'b1; after_snd<=S_RD_D;    state<=S_SND_ISS; end
                S_RD_D: begin snd_data <= 8'h00;                    snd_hold<=1'b0; after_snd<=after_reg; state<=S_SND_ISS; end

                // ================= enviar 1 byte por SPI =================
                S_SND_ISS:  begin spi_tx<=snd_data; spi_hold_cs<=snd_hold; spi_start<=1'b1; state<=S_SND_BUSY; end
                S_SND_BUSY: begin if (spi_busy) state<=S_SND_WT; end
                S_SND_WT:   begin if (!spi_busy) begin rx_cap<=spi_rx; state<=after_snd; end end

                default: state <= S_IDLE;
            endcase
        end
    end
endmodule
