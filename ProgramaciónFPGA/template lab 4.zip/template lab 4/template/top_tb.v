// filename: top_tb.v
`timescale 1ns / 1ns

`ifndef TIME_UNIT
`define TIME_UNIT 10
`endif

// 1. El modulo DEBE llamarse top_tb para coincidir con el Makefile
module top_tb;

  reg        clk = 0;
  always #(`TIME_UNIT) clk = !clk;      // reloj simulado (periodo 20 ns)

  reg        rst = 1'b1;
  wire [3:0] filas;
  wire [3:0] codigoTecla;
  wire       teclaValida;

  // ---- EMULACION DE LA MATRIZ FISICA DEL TECLADO ----
  reg        teclaPresionada = 1'b0;
  reg  [1:0] filaTecla       = 2'd0;
  reg  [3:0] patronTecla     = 4'b1111;

  wire [3:0] columnas = (teclaPresionada && (filas[filaTecla] === 1'b0))
                        ? patronTecla : 4'b1111;

  integer    pulsos  = 0;
  integer    errores = 0;
  reg  [3:0] ultimoCodigo = 4'hF;

  // DUT: PASO=4 acelera el barrido para que la simulacion sea corta
  // (en la FPGA el parametro por defecto es 50_000 = 1 ms por fila)
  top #(.PASO(4)) dut (
      .clk(clk),
      .rst(rst),
      .columnas(columnas),
      .filas(filas),
      .codigoTecla(codigoTecla),
      .teclaValida(teclaValida)
  );

  initial begin
    $dumpfile("top_tb.vcd");
    // 2. El nombre aqui debe ser exactamente el del modulo
    $dumpvars(0, top_tb);
  end

  // VISUALIZACION EN CONSOLA
  initial begin
    $monitor("Tiempo: %0t ns | clk: %b | filas: %b | columnas: %b | codigo: %0d | valida: %b",
             $time, clk, filas, columnas, codigoTecla, teclaValida);
  end

  // Contador de pulsos emitidos por el DUT
  always @(posedge clk) begin
    if (teclaValida) begin
      pulsos       = pulsos + 1;
      ultimoCodigo = codigoTecla;
    end
  end

  //---------------------------------------------------------------
  //  Tareas de estimulo
  //---------------------------------------------------------------
  task pulsarTecla;               // cierra el contacto de una tecla y la
    input [1:0] filaObj;          // mantiene pulsada. Ya NO hay que
    input [3:0] patronCol;        // sincronizar con el barrido: la matriz
    begin                         // emulada se encarga sola.
      filaTecla       = filaObj;
      patronTecla     = patronCol;
      teclaPresionada = 1'b1;
      // sostener lo suficiente para cubrir una vuelta completa del barrido
      repeat (60) @(posedge clk);
    end
  endtask

  task soltarTecla;
    begin
      teclaPresionada = 1'b0;       // se abre el contacto
      // margen para que el DUT limpie el enclavamiento 'sostenida'
      repeat (40) @(posedge clk);
    end
  endtask

  task revisar;
    input [127:0] nombre;
    input integer esperado;
    input integer obtenido;
    begin
      if (esperado === obtenido)
        $display(">> OK    %0s (esperado=%0d, obtenido=%0d)", nombre, esperado, obtenido);
      else begin
        $display(">> FALLA %0s (esperado=%0d, obtenido=%0d)", nombre, esperado, obtenido);
        errores = errores + 1;
      end
    end
  endtask

  //---------------------------------------------------------------
  //  Secuencia de prueba (verifica el comportamiento de la ASM)
  //---------------------------------------------------------------
  initial begin
    // Reset
    repeat (3) @(posedge clk);
    rst = 1'b0;
    repeat (5) @(posedge clk);

    // [1] Barrido libre: no debe haber pulsos
    repeat (60) @(posedge clk);
    revisar("sin pulsos espurios", 0, pulsos);

    // [2] Tecla '5' (fila 1, columna 1)
    pulsarTecla(2'd1, 4'b1101);
    revisar("un solo pulso", 1, pulsos);
    revisar("codigo = 5", 5, ultimoCodigo);

    // [3] Mantenerla pulsada: NO debe repetir
    repeat (60) @(posedge clk);
    revisar("sigue en un pulso", 1, pulsos);

    // [4] Soltar y volver a pulsar
    soltarTecla();
    pulsarTecla(2'd1, 4'b1101);
    revisar("segundo pulso", 2, pulsos);

    // [5] Tecla '#' (fila 3, columna 2)
    soltarTecla();
    pulsarTecla(2'd3, 4'b1011);
    revisar("tercer pulso", 3, pulsos);
    revisar("codigo = 15 ('#')", 15, ultimoCodigo);

    // [6] Tecla 'A' (fila 0, columna 3)
    soltarTecla();
    pulsarTecla(2'd0, 4'b0111);
    revisar("cuarto pulso", 4, pulsos);
    revisar("codigo = 10 ('A')", 10, ultimoCodigo);

    soltarTecla();

    if (errores == 0) $display("\n== TODAS LAS PRUEBAS PASARON ==\n");
    else              $display("\n== HUBO %0d FALLAS ==\n", errores);

    $finish();
  end

  // Guardia de tiempo maximo
  initial begin
    #(`TIME_UNIT * 60000) $display("TIMEOUT");
    $finish();
  end

endmodule